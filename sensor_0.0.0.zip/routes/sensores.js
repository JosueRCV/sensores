'use strict';
const dd = require('dedent');
const joi = require('joi');
const httpError = require('http-errors');
const status = require('statuses');
const errors = require('@arangodb').errors;
const createRouter = require('@arangodb/foxx/router');
const Sensore = require('../models/sensore');

const sensores = module.context.collection('sensores');
const keySchema = joi.string().required()
.description('The key of the sensore');

const ARANGO_NOT_FOUND = errors.ERROR_ARANGO_DOCUMENT_NOT_FOUND.code;
const ARANGO_DUPLICATE = errors.ERROR_ARANGO_UNIQUE_CONSTRAINT_VIOLATED.code;
const ARANGO_CONFLICT = errors.ERROR_ARANGO_CONFLICT.code;
const HTTP_NOT_FOUND = status('not found');
const HTTP_CONFLICT = status('conflict');

const router = createRouter();
module.exports = router;


router.tag('sensore');


router.get(function (req, res) {
  res.send(sensores.all());
}, 'list')
.response([Sensore], 'A list of sensores.')
.summary('List all sensores')
.description(dd`
  Retrieves a list of all sensores.
`);


router.post(function (req, res) {
  const sensore = req.body;
  let meta;
  try {
    meta = sensores.save(sensore);
  } catch (e) {
    if (e.isArangoError && e.errorNum === ARANGO_DUPLICATE) {
      throw httpError(HTTP_CONFLICT, e.message);
    }
    throw e;
  }
  Object.assign(sensore, meta);
  res.status(201);
  res.set('location', req.makeAbsolute(
    req.reverse('detail', {key: sensore._key})
  ));
  res.send(sensore);
}, 'create')
.body(Sensore, 'The sensore to create.')
.response(201, Sensore, 'The created sensore.')
.error(HTTP_CONFLICT, 'The sensore already exists.')
.summary('Create a new sensore')
.description(dd`
  Creates a new sensore from the request body and
  returns the saved document.
`);


router.get(':key', function (req, res) {
  const key = req.pathParams.key;
  let sensore
  try {
    sensore = sensores.document(key);
  } catch (e) {
    if (e.isArangoError && e.errorNum === ARANGO_NOT_FOUND) {
      throw httpError(HTTP_NOT_FOUND, e.message);
    }
    throw e;
  }
  res.send(sensore);
}, 'detail')
.pathParam('key', keySchema)
.response(Sensore, 'The sensore.')
.summary('Fetch a sensore')
.description(dd`
  Retrieves a sensore by its key.
`);


router.put(':key', function (req, res) {
  const key = req.pathParams.key;
  const sensore = req.body;
  let meta;
  try {
    meta = sensores.replace(key, sensore);
  } catch (e) {
    if (e.isArangoError && e.errorNum === ARANGO_NOT_FOUND) {
      throw httpError(HTTP_NOT_FOUND, e.message);
    }
    if (e.isArangoError && e.errorNum === ARANGO_CONFLICT) {
      throw httpError(HTTP_CONFLICT, e.message);
    }
    throw e;
  }
  Object.assign(sensore, meta);
  res.send(sensore);
}, 'replace')
.pathParam('key', keySchema)
.body(Sensore, 'The data to replace the sensore with.')
.response(Sensore, 'The new sensore.')
.summary('Replace a sensore')
.description(dd`
  Replaces an existing sensore with the request body and
  returns the new document.
`);


router.patch(':key', function (req, res) {
  const key = req.pathParams.key;
  const patchData = req.body;
  let sensore;
  try {
    sensores.update(key, patchData);
    sensore = sensores.document(key);
  } catch (e) {
    if (e.isArangoError && e.errorNum === ARANGO_NOT_FOUND) {
      throw httpError(HTTP_NOT_FOUND, e.message);
    }
    if (e.isArangoError && e.errorNum === ARANGO_CONFLICT) {
      throw httpError(HTTP_CONFLICT, e.message);
    }
    throw e;
  }
  res.send(sensore);
}, 'update')
.pathParam('key', keySchema)
.body(joi.object().description('The data to update the sensore with.'))
.response(Sensore, 'The updated sensore.')
.summary('Update a sensore')
.description(dd`
  Patches a sensore with the request body and
  returns the updated document.
`);


router.delete(':key', function (req, res) {
  const key = req.pathParams.key;
  try {
    sensores.remove(key);
  } catch (e) {
    if (e.isArangoError && e.errorNum === ARANGO_NOT_FOUND) {
      throw httpError(HTTP_NOT_FOUND, e.message);
    }
    throw e;
  }
}, 'delete')
.pathParam('key', keySchema)
.response(null)
.summary('Remove a sensore')
.description(dd`
  Deletes a sensore from the database.
`);
