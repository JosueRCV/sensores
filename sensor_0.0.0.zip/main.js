'use strict';

module.context.use('/sensores', require('./routes/sensores'), 'sensores');
